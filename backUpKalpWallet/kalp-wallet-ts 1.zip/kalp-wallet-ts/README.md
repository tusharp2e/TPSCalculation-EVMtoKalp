# test-kalp-wallet-package

1. submit
2. getKeyPair,
3. register,
4. createCsr,
5. getEnrollmentId,
6. submitTransaction,
7. getSeedPhrase,
8. signUsingElliptic,
9. evaluateTransaction,
10. evaluateTransactionBalance,

# To DO

1. need to remove the Authorization layer (registration function)
